# Azure deployment notes (starter)
- Use Azure Key Vault for secrets.
- Use Azure Container Registry (ACR) + AKS or Container Apps to run the backend.
- For LLM workloads, use Azure OpenAI service (apply for access if necessary).
- For anchoring, evaluate Managed CCF (preview) or run a permissioned ledger in AKS.
- This folder is intentionally light; each organization will adapt infra to their compliance needs.
