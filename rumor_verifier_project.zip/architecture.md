# Architecture & Azure Mapping

## Overview
Pipeline stages:
1. **Ingest** - collect news articles, tweets, RSS feeds, and broker notifications in real-time.
2. **Preprocess** - clean, extract metadata (tickers, timestamps, authors).
3. **Verify (GenAI + Heuristics)** - use Azure OpenAI for:
   - Claim classification (rumor / likely / verified).
   - Generative explanation & summary.
   - Similarity search using embeddings to find corroborating sources.
4. **Evidence Collection** - fetch corroborating documents / web snapshots.
5. **Anchoring** - create Merkle tree over evidence and anchor the root hash to a blockchain (or managed service).
6. **Audit & UI** - present auditor-friendly proofs (hashes + evidence pointers).

## Recommended Azure Services (2025)
- **Azure OpenAI / Azure AI Foundry**: for LLM access (classification, summarization, embeddings). See Azure docs.
- **Azure Functions / Azure Container Apps**: serverless ingestion & small workers.
- **Azure Kubernetes Service (AKS)**: for production orchestration of microservices.
- **Azure Blob Storage**: store raw snapshots, evidence, and encrypted payloads.
- **Azure Managed Confidential Consortium Framework (Managed CCF)** or **self-managed consortium (Hyperledger/Quorum)**:
  Azure Blockchain Service was retired in 2021 — consider Managed CCF or running a permissioned network in AKS.
- **Azure Key Vault**: store API keys and signing keys.
- **Event Hubs / Service Bus**: reliable ingestion & eventing.
- **Azure Monitor / Log Analytics**: observability.

## Anchoring strategies
- **Public chain anchor**: store Merkle root in an on-chain transaction (e.g., Ethereum) — easy public audit.
- **Consortium anchor**: use Managed CCF or Hyperledger Fabric for private, permissioned anchoring.
- **Hybrid**: periodically batch Merkle roots and anchor a single digest to a public chain for public timestamping.

## Security & Privacy
- Never place raw user data on-chain. Store only hashes / Merkle roots.
- Use encryption-at-rest (Blob Storage) and TLS in transit.
- Follow Azure OpenAI data policies (do not send PII unnecessarily).

## References
- Azure OpenAI docs (samples and SDK).  
- Microsoft Managed CCF pages.  
- Research on blockchain timestamping and anchoring patterns.
