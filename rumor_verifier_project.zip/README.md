# Real-time Rumor-to-Reality Verifier for Stock News (Azure + GenAI + Blockchain Anchoring)

This repository is a complete project skeleton designed for demonstration, development, and deployment.
It shows how to build a pipeline that ingests stock-related news/social posts, uses Azure OpenAI (GenAI)
for classification/verification and embeddings-based search, and anchors tamper-evident hashes
(Merkle roots) to a blockchain (anchor) for immutable audit trails.

## What’s included
- `backend/` FastAPI app with ingestion, verification, and anchoring endpoints.
- `verifier/` utilities for hashing, merkle root creation, and example anchor stubs.
- `azure/` deployment & infra placeholders (Bicep template, README).
- `docker-compose.yml` and `Dockerfile` for local testing.
- `architecture.md` — explanation & recommended Azure services.
- `LICENSE` (MIT)

## How to use
1. Read `architecture.md` for design decisions and Azure service recommendations.
2. Fill in Azure credentials and keys in environment variables shown in `backend/.env.example`.
3. Run backend locally:
   ```
   cd backend
   python -m venv .venv
   source .venv/bin/activate    # or .venv\Scripts\activate on Windows
   pip install -r requirements.txt
   uvicorn main:app --reload --host 0.0.0.0 --port 8000
   ```
4. Use the `/ingest`, `/verify`, and `/anchor` endpoints to test flows. See inline comments.

## Notes / Next steps
- The anchoring implementations are provided as secure *stubs* and examples. For production,
  choose an anchoring strategy: public chains (e.g., Ethereum), consortium frameworks (e.g., Microsoft CCF),
  or third-party timestamping services. See `architecture.md`.
- Replace example keys with Azure-managed identities or Key Vault references in production.

Enjoy — modify freely and use this as the base for your seminar, demo, or production prototype.
