# Example Azure OpenAI usage (embeddings + simple classification)
# NOTE: requires `azure-ai-openai` and correct environment variables.
import os
from azure.ai.openai import OpenAIClient
from azure.identity import DefaultAzureCredential
import asyncio

# This example uses api-key authentication for simplicity.
from azure.ai.openai import OpenAIClient
from azure.core.credentials import AzureKeyCredential

endpoint = os.getenv('AZURE_OPENAI_ENDPOINT')
key = os.getenv('AZURE_OPENAI_KEY')
deployment = os.getenv('AZURE_OPENAI_DEPLOYMENT') or 'gpt-deployment'

client = OpenAIClient(endpoint, AzureKeyCredential(key)) if endpoint and key else None

async def classify_claim(text: str) -> str:
    """Simple prompt to classify text as 'rumor', 'likely', or 'verified'.
    Replace with a robust prompt and safety checks for production.
    """
    if not client:
        return 'unknown (no client configured)'
    prompt = f"Classify the following stock news text as 'rumor', 'likely', or 'verified':\n\n{text}\n\nLabel:"
    resp = client.get_chat_response(deployment, messages=[{"role":"user","content":prompt}])
    # resp parsing depends on SDK shape; this is a conceptual example.
    return resp.choices[0].message.content.strip()

async def embed_text(text: str):
    if not client:
        return []
    resp = client.get_embeddings(deployment=deployment, input=text)
    return resp.data[0].embedding
