# Anchoring utilities (demo)
import hashlib
import json

def _hash(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def make_merkle_root(items):
    # Simple merkle root: pairwise hash (not optimized)
    nodes = [_hash(i.encode('utf-8')) for i in items]
    if not nodes:
        return None
    while len(nodes) > 1:
        new = []
        for i in range(0, len(nodes), 2):
            a = nodes[i]
            b = nodes[i+1] if i+1 < len(nodes) else nodes[i]
            new.append(_hash((a + b).encode('utf-8')))
        nodes = new
    return nodes[0]

def anchor_to_stub(merkle_root):
    """Demo stub: in production, send a transaction to a chain (e.g., Ethereum) or to Managed CCF.
    This function returns a fake 'tx' id and shows where to integrate web3 or SDKs.
    """
    # Example return to show flow
    return 'STUB-ANCHOR-TX-' + merkle_root[:10]
