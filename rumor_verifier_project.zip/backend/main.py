# FastAPI sample backend (simplified demo)
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from verifier.anchor import make_merkle_root, anchor_to_stub
from verifier.azure_openai_client import classify_claim, embed_text

app = FastAPI(title="Rumor-to-Reality Verifier (demo)")

class IngestItem(BaseModel):
    id: str
    source: str
    text: str
    timestamp: str

@app.post('/ingest')
async def ingest(item: IngestItem):
    # In production: validate, sanitize, persist to Blob/DB, push event to Event Hub
    # For demo: run classification and return result
    label = await classify_claim(item.text)
    return {'id': item.id, 'label': label}

@app.post('/verify')
async def verify(item: IngestItem):
    # Use embeddings to find similar evidence (not implemented here)
    embedding = await embed_text(item.text)
    # return placeholder verification result
    return {'id': item.id, 'label': 'likely', 'embedding_len': len(embedding)}

@app.post('/anchor')
async def anchor(payload: dict):
    # payload: { 'evidence': [ 'text1', 'text2', ... ] }
    evidence = payload.get('evidence', [])
    if not evidence:
        raise HTTPException(400, 'no evidence provided')
    merkle_root = make_merkle_root(evidence)
    tx = anchor_to_stub(merkle_root)
    return {'merkle_root': merkle_root, 'anchor_tx': tx}
